function [OffspringX, OffspringF] = F_select(Population, FunctionValue, N)

OffspringX = []; OffspringF = [];

%ѡ����֧��ĸ���
[FrontValue,MaxFront] = P_sort(FunctionValue,'half');
Next = zeros(1,N);
NoN = numel(FrontValue,FrontValue<MaxFront);
Next(1:NoN) = find(FrontValue<MaxFront);

Last = find(FrontValue==MaxFront);

CrowdDistance = F_distance(FunctionValue,FrontValue);
[~,Rank] = sort(CrowdDistance(Last),'descend');

%[~,Rank] = sort(FunctionValue(Last,2),'ascend');

Next(NoN+1:N) = Last(Rank(1:N-NoN));
OffspringX = [OffspringX; Population(Next,:)];
OffspringF = [OffspringF; FunctionValue(Next,:)];
    
end

