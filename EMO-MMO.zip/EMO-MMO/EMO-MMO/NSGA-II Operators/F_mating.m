function MatingPool = F_mating(Population,FrontValue,CrowdDistance, delta)
%�����ѡ��

    [N,D] = size(Population);
    MatingPool = Population;
    
    
    % random mating
    MatingPool = Population(randperm(N),:);
    
    % clustering based mating
%     K = 6; 
%     class = struct('c', cell(1,K)); 
%     [idx, centers] = kmeans(Population,K);
%     for i = 1:N;
%         class(idx(i)).c = [class(idx(i)).c, i];
%     end;
%     for i = 1:2:N
%         %ѡ����ĸ
%         B = class(idx(i)).c;
%         if rand < delta
%             P = B;
%         else
%             P = 1:N;
%         end
%         k1 = P(ceil(rand()*length(P)));
%         k2 = P(ceil(rand()*length(P)));
%         MatingPool(i,:) = Population(k1,:);
%         MatingPool(i + 1,:) = Population(k2,:);
%     end


%nearest neighbors
%     Dist = pdist2(Population, Population);
%     Dist(logical(eye(size(Dist)))) = 1e20;
%     [~,B] = min(Dist, [], 2);
%     RandList = randperm(N);
%     MatingPool(1:2:end,:) = Population(RandList(1:N/2),:);
%     MatingPool(2:2:end,:) = Population(B(RandList(1:N/2)),:);
%     


    
    %neighborhood based selection
%     T = floor(10);
%     delta = 1.0;
%     %�ھ��ж�
%     B = zeros(N);
%     for i = 1 : N-1
%         for j = i+1 : N
%             B(i,j) = norm(Population(i,:)-Population(j,:));
%             B(j,i) = B(i,j);
%         end
%     end
%     [sortedB,B] = sort(B,2, 'ascend');
%     B = B(:,1:T);
%     
%     for i = 1:2:N
%         %ѡ����ĸ
%         if rand < delta
%             P = B(i,:);
%         else
%             P = 1:N;
%         end
%         k = randperm(length(P));
%         
%         MatingPool(i,:) = Population(P(k(1)),:);
%         MatingPool(i + 1,:) = Population(P(k(2)),:);
%     end
%     
    
    %��Ԫ����ѡ��
%     MatingPool = zeros(N,D);
%     Rank = randperm(N);
%     Pointer = 1;
%     for i = 1 : 2 : N
%         %ѡ��ĸ
%         k = zeros(1,2);
%         for j = 1 : 2
%             if Pointer >= N
%                 Rank = randperm(N);
%                 Pointer = 1;
%             end
%             p = Rank(Pointer);
%             q = Rank(Pointer+1);
%             if FrontValue(p) < FrontValue(q)
%                 k(j) = p;
%             elseif FrontValue(p) > FrontValue(q)
%                 k(j) = q;
%             elseif CrowdDistance(p) > CrowdDistance(q)
%                 k(j) = p;
%             else
%                 k(j) = q;
%             end
%             Pointer = Pointer+2;
%         end
%         MatingPool(i,:) = Population(k(1),:);
%         MatingPool(i+1,:) = Population(k(2),:);
%     end

% % raduis based neighborhood
% Neighborhood = cell(0,0);
% Dist =  pdist2(Population, Population, 'minkowski', 1);
% Dist(Dist == 0) = 1e200;
% R = max(min(Dist, [], 2));
% mask = Dist < R;
% for i = 1:N
%     Neighborhood(i) = {find(mask(i,:) == 1)};
% end;
% for i = 1:2:N
%     %ѡ����ĸ
%     if length(Neighborhood{i}) > 1
%         P = Neighborhood{i};
%     else
%         P = 1:N;
%     end
%     k = randperm(length(P));
%     MatingPool(i,:) = Population(P(k(1)),:);
%     MatingPool(i + 1,:) = Population(P(k(2)),:);
% end


if(mod(size(MatingPool,1), 2) == 1)
    MatingPool = [MatingPool; MatingPool(1,:)];
end;
    
end

