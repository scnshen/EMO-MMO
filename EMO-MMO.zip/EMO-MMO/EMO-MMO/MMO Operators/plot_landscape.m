function [] = plot_landscape(all_x, all_f)
    if(size(all_x,2) == 1)
        % plot(all_x(:,1), -all_f(:,1),'ko', 'MarkerFace', 'k');
        plot(all_x(:,1), -all_f(:,1),'k.');
    else
        meshx = all_x;
        meshy = -all_f(:,1);
        % plot3(meshx(:,2), meshx(:,1), meshy(:,1), 'ko', 'MarkerFace', 'k');
        plot3(meshx(:,2), meshx(:,1), meshy(:,1), 'k.');
        %view(-30,30);
        xlim([min(all_x(:,2)) max(all_x(:,2))]);
        ylim([min(all_x(:,1)) max(all_x(:,1))]);
        %zlim([min(all_f(:,1))-1 max(all_f(:,1))+1];
        %zlim([-50 0]);
        grid on;
        
        xlabel('$x_2$','Interpreter','LaTex');
        ylabel('$x_1$','Interpreter','LaTex');
        zlabel('$f(\mathbf{x})$','Interpreter','LaTex');
        set(gca,'fontsize',16);
    end;
end
